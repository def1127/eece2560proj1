Compile and execution information:
    - Execute compilation using "make".
    - Execute compiled file using "./main"